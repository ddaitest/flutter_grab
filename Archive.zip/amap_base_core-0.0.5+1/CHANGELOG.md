## 0.0.5
* LatLng增加加减乘除的操作符

## 0.0.4
* 权限管理使用`permission_handler`处理

## 0.0.3
* 加入log, misc, permissions

## 0.0.2
* 抽取`AMap`

## 0.0.1
* 抽取LatLng
