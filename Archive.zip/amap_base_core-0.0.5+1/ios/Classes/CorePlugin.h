#import <Flutter/Flutter.h>

@interface CorePlugin : NSObject<FlutterPlugin>
@end
