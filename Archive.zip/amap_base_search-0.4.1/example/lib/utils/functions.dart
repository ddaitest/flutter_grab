final notEqual = (prev, next) => prev != next;
