enum ErrorLevel {
  none,
  warn,
  severe,
  fatal,
}

enum Actions {
  cancel,
  confirm,
}
