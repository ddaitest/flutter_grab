#import <Flutter/Flutter.h>

@interface AMapBaseSearchPlugin : NSObject <FlutterPlugin>

+ (NSObject <FlutterPluginRegistrar> *)registrar;

@end
