//
//  Misc.h
//  SearchV3Demo
//
//  Created by songjian on 13-8-22.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Flutter/Flutter.h"

@interface Misc : NSObject


+(NSString* ) toAMapErrorDesc:(NSInteger) errorCode;

@end
