package me.yohom.amapbasesearch

import io.flutter.plugin.common.MethodChannel

interface SearchMethodHandler : MethodChannel.MethodCallHandler