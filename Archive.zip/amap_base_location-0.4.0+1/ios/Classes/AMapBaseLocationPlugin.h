#import <Flutter/Flutter.h>

@interface AMapBaseLocationPlugin : NSObject <FlutterPlugin>

+ (NSObject <FlutterPluginRegistrar> *)registrar;

@end
