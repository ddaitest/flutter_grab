package me.yohom.amapbaselocation

import io.flutter.plugin.common.MethodChannel

interface SearchMethodHandler : MethodChannel.MethodCallHandler

interface MapMethodHandler: MethodChannel.MethodCallHandler

interface NaviMethodHandler: MethodChannel.MethodCallHandler

interface LocationMethodHandler: MethodChannel.MethodCallHandler