const MAP_TYPE_NORMAL = 1;
const MAP_TYPE_SATELLITE = 2;
const MAP_TYPE_NIGHT = 3;
const MAP_TYPE_NAVI = 4;
const MAP_TYPE_BUS = 5;
