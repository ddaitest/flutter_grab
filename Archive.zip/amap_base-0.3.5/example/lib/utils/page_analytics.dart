abstract class PageAnalytics {
  void onPageStart(String page);

  void onPageEnd(String page);
}
