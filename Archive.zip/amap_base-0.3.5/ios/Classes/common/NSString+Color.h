//
// Created by Yohom Bao on 2018-12-10.
//

#import <Foundation/Foundation.h>

@interface NSString (Color)

- (UIColor *)hexStringToColor;

@end