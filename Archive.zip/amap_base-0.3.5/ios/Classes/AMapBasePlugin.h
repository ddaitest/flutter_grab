#import <Flutter/Flutter.h>

@interface AMapBasePlugin : NSObject <FlutterPlugin>

+ (NSObject <FlutterPluginRegistrar> *)registrar;

@end
